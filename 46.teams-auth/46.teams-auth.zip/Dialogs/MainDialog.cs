﻿using System.Threading;
using System.Threading.Tasks;
using Microsoft.Bot.Builder;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Schema;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

using System.IO;
using Microsoft.Bot.Builder.LanguageGeneration;
using Microsoft.Bot.Builder.Dialogs.Adaptive.Generators;
using TeamsAuth.Models;
using Microsoft.Graph;

namespace Microsoft.BotBuilderSamples
{
    public class MainDialog : LogoutDialog
    {
        private static Templates _templates;
        protected readonly ILogger Logger;

        private string helpInputStr = "";
        public HelpClass helpInput;
        private string manageUserInputStr = "";
        public ManageUserClass manageUserClass = new ManageUserClass();
        private string manageGroupInputStr = "";
        public ManageGroupClass manageGroupClass = new ManageGroupClass();
        private string manageGroupMode = "create"; // create, update
        private TokenResponse logintoken;

        public MainDialog(IConfiguration configuration, ILogger<MainDialog> logger)
            : base(nameof(MainDialog), configuration["ConnectionName"])
        {
            // combine path for cross platform support
            string[] paths = { ".", "Dialogs", "MainDialog.lg" };
            string fullPath = Path.Combine(paths);
            _templates = Templates.ParseFile(fullPath);

            Logger = logger;

            //define all dialogs needed in this project. line 44 - 128

            AddDialog(new OAuthPrompt(
                nameof(OAuthPrompt),
                new OAuthPromptSettings
                {
                    ConnectionName = ConnectionName,
                    Text = "You are not signed in.\n\nSign in by tapping the button.",
                    Title = "Sign In",
                    Timeout = 300000, // User has 5 minutes to login (1000 * 60 * 5)
                    EndOnInvalidMessage = true
                }));

            AddDialog(new ConfirmPrompt(nameof(ConfirmPrompt)));

            AddDialog(new TextPrompt(nameof(TextPrompt)));

            AddDialog(new WaterfallDialog( "logingWaterfall", new WaterfallStep[]
            {
                PromptStepAsync,
                LoginStepAsync,
            }));

            AddDialog(new WaterfallDialog("helpWaterfall", new WaterfallStep[]
            {
                HelpPromptStepAsync,
                HelpRedirectStepAsync,
            }));

            AddDialog(new WaterfallDialog("ResetPasswordWaterfall", new WaterfallStep[]
            {
                CurrentPasswordStepAsync,
                NewPasswordStepAsync,
                RepeatNewPasswordStepAsync,
                ResetPasswordStepAsync,
            }));

            AddDialog(new WaterfallDialog("CreateNewUserWaterfall", new WaterfallStep[]
            {
                UserDisplayNameStepAsync,
                UserMailNicknameStepAsync,
                UserPrincipalNameStepAsync,
                AccountEnabledStepAsync,
                PostNewUserStepAsync,
            }));

            //AddDialog(new WaterfallDialog("NaamVanDitDialoog", new WaterfallStep[]
            //{
            //    Step01Async,
            //    Step02Async,
            //    Step03Async,
            //    Step04Async,
            //    Step05Async,
            //}));

            //AddDialog(new WaterfallDialog("AssignLicenseWaterfall", new WaterfallStep[]
            //{
            //    AssignLicenseStepAsync,

            //}));

            AddDialog(new WaterfallDialog("CreateNewGroupWaterfall", new WaterfallStep[]
            {
                GroupDisplayNameStepAsync,
                GroupDescriptionStepAsync,
                GroupMailNicknameStepAsync,
                PostNewGroupStepAsync,
            }));

            AddDialog(new WaterfallDialog("UpdateGroupWaterfall", new WaterfallStep[]
            {
                GroupIdStepAsync,
                //GetExistingGroupStepAsync,
                GroupDisplayNameStepAsync,
                GroupDescriptionStepAsync,
                GroupMailNicknameStepAsync,
                PostNewGroupStepAsync,
            }));

            AddDialog(new WaterfallDialog("DeleteGroupWaterfall", new WaterfallStep[]
            {
                GroupIdDeleteStepAsync,
                GroupDeleteConfirmationStepAsync,
                GroupDeleteStepAsync,
            }));

            // The initial child Dialog to run.
            InitialDialogId = "logingWaterfall";

            Generator = new TemplateEngineLanguageGenerator(Templates.ParseFile(fullPath));
        }

        private async Task<DialogTurnResult> PromptStepAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            return await stepContext.BeginDialogAsync(nameof(OAuthPrompt), null, cancellationToken);
        }
                   
        private async Task<DialogTurnResult> LoginStepAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            // Get the token from the previous step. Note that we could also have gotten the
            // token directly from the prompt itself. There is an example of this in the next method.
            var tokenResponse = (TokenResponse)stepContext.Result;
            logintoken = (TokenResponse)stepContext.Result;
            if (tokenResponse?.Token != null)
            {
                if (IsLoggedIn == false) {

                // Pull in the data from the Microsoft Graph API.
                var client = new SimpleGraphClient(tokenResponse.Token);
                var me = await client.GetMeAsync();
                var title = !string.IsNullOrEmpty(me.JobTitle) ?
                            me.JobTitle : "Unknown";

                // Show the data from the Microsoft Graph API.
                await stepContext.Context.SendActivityAsync(
                    $"You're logged in as {me.DisplayName} ({me.UserPrincipalName})."+
                    $"\n\nYour job title is: {title}");

                    IsLoggedIn = true;
                }

                // Redirect to the helpdialog.
                return await stepContext.ReplaceDialogAsync("helpWaterfall");
            }

            await stepContext.Context.SendActivityAsync(MessageFactory.Text("Login was not successful please try again."), cancellationToken);
            return await stepContext.EndDialogAsync(cancellationToken: cancellationToken);
        }

        private async Task<DialogTurnResult> HelpPromptStepAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            // Define the messageprompt for this WaterfallStep.
            var promptOptions = new PromptOptions
            {
                Prompt = ActivityFactory.FromObject(_templates.Evaluate("HelpMessage")),
            };
            
            // Define new object of HelpClass to retrieve userinput in later stages of this WaterfallDialog.
            stepContext.Values[helpInputStr] = new HelpClass();
            return await stepContext.PromptAsync(nameof(TextPrompt), promptOptions, cancellationToken);
        }


        private async Task<DialogTurnResult> HelpRedirectStepAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            // Retrieve userinput from the previous step in this WaterfallDialog.
            var helpInput = (HelpClass)stepContext.Values[helpInputStr];
            helpInput.helpInput = (string)stepContext.Result;

            // Redirect to a fitting WaterfallDialog based on the userinput.
            switch (helpInput.helpInput.ToString())
            {
                case "reset password":
                    return await stepContext.ReplaceDialogAsync("ResetPasswordWaterfall");
                //case "assign license":
                //    return await stepContext.ReplaceDialogAsync("AssignLicenseWaterfall");
                case "create user":
                    return await stepContext.ReplaceDialogAsync("CreateNewUserWaterfall");
                case "create group":
                    return await stepContext.ReplaceDialogAsync("CreateNewGroupWaterfall");
                case "update group":
                    return await stepContext.ReplaceDialogAsync("UpdateGroupWaterfall");
                case "delete group":
                    return await stepContext.ReplaceDialogAsync("DeleteGroupWaterfall");
                case "help":
                case "?":
                    await stepContext.Context.SendActivityAsync(MessageFactory.Text(
                        "This is a list with all the possible commands:\n\n" +
                        "reset password,\n\n" +
                        //"assign license,\n\n" +
                        "create user,\n\n" +
                        "create group,\n\n" +
                        "delete group,\n\n" +
                        "help,\n\n" +
                        "logout"));
                    return await stepContext.ReplaceDialogAsync("helpWaterfall");
                default:
                    await stepContext.Context.SendActivityAsync(MessageFactory.Text("I'm Sorry. I didn't get that." +
                        "\n\nType 'help' for a list of possible commands."));
                    return await stepContext.ReplaceDialogAsync("helpWaterfall");
            }
        }

        private async Task<DialogTurnResult> CurrentPasswordStepAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            // Define the messageprompt for this WaterfallStep.
            var promptOptions = new PromptOptions
            {
                Prompt = ActivityFactory.FromObject(_templates.Evaluate("AskForCurrentPassword")),
            };

            // Define object of ManageUserClass to retrieve userinput in the next WaterfallStep.
            stepContext.Values[manageUserInputStr] = new ManageUserClass();
            return await stepContext.PromptAsync(nameof(TextPrompt), promptOptions, cancellationToken);
        }

        private async Task<DialogTurnResult> NewPasswordStepAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            // Define the messageprompt for this WaterfallStep.
            var promptOptions = new PromptOptions
            {
                Prompt = ActivityFactory.FromObject(_templates.Evaluate("AskForNewPassword")),
            };

            // Retrieve userinput from the previous step in this WaterfallDialog and put the value in a global object.
            var currentPasswordInput = (ManageUserClass)stepContext.Values[manageUserInputStr];
            currentPasswordInput.currentPassword = (string)stepContext.Result;

            manageUserClass.currentPassword = currentPasswordInput.currentPassword;

            // Redefine object of ManageUserClass to retrieve userinput in the next WaterfallStep.
            stepContext.Values[manageUserInputStr] = new ManageUserClass();
            return await stepContext.PromptAsync(nameof(TextPrompt), promptOptions, cancellationToken);
        }

        private async Task<DialogTurnResult> RepeatNewPasswordStepAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            // Define the messageprompt for this WaterfallStep.
            var promptOptions = new PromptOptions
            {
                Prompt = ActivityFactory.FromObject(_templates.Evaluate("AskForNewPasswordAgain")),
            };

            // Retrieve userinput from the previous step in this WaterfallDialog and put the value in a global object.
            var newPasswordInput = (ManageUserClass)stepContext.Values[manageUserInputStr];
            newPasswordInput.newPassword = (string)stepContext.Result;

            manageUserClass.newPassword = newPasswordInput.newPassword;

            // Redefine object of ManageUserClass to retrieve userinput in the next WaterfallStep.
            stepContext.Values[manageUserInputStr] = new ManageUserClass();
            return await stepContext.PromptAsync(nameof(TextPrompt), promptOptions, cancellationToken);
        }
        private async Task<DialogTurnResult> ResetPasswordStepAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            // Retrieve userinput from the previous step in this WaterfallDialog and put the value in a global object.
            var controlNewPasswordInput = (ManageUserClass)stepContext.Values[manageUserInputStr];
            controlNewPasswordInput.contolNewPassword = (string)stepContext.Result;

            manageUserClass.contolNewPassword = controlNewPasswordInput.contolNewPassword;

            if (manageUserClass.newPassword == manageUserClass.contolNewPassword)
            {
                // Use your authenticationtoken and the fully filled global object to change your password 
                // with the SimpleGraphClient
                var tokenResponse = logintoken;
                var client = new SimpleGraphClient(tokenResponse.Token);
                await client.PostNewPasswordAsync(manageUserClass);

                // Reset the global object for later use and redirect to the helpdialog.
                manageUserClass.resetValues();

                await stepContext.Context.SendActivityAsync(ActivityFactory.FromObject(_templates.Evaluate("PasswordResetSuccessMessage")));
                return await stepContext.ReplaceDialogAsync("helpWaterfall");
            }

            else
            {
                // Reset the global object for later use and redirect to the helpdialog.
                manageUserClass.resetValues();

                await stepContext.Context.SendActivityAsync(ActivityFactory.FromObject(_templates.Evaluate("PasswordResetFailMessage")));
                return await stepContext.ReplaceDialogAsync("helpWaterfall");
            }
            
        }

        private async Task<DialogTurnResult> UserDisplayNameStepAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            // Define the messageprompt for this WaterfallStep.
            var promptOptions = new PromptOptions
            {
                Prompt = ActivityFactory.FromObject(_templates.Evaluate("AskForDisplayName")),
            };

            // Define object of ManageUserClass to retrieve userinput in the next WaterfallStep.
            stepContext.Values[manageUserInputStr] = new ManageUserClass();

            return await stepContext.PromptAsync(nameof(TextPrompt), promptOptions, cancellationToken);
        }

        private async Task<DialogTurnResult> UserMailNicknameStepAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            // Define the messageprompt for this WaterfallStep.
            var promptOptions = new PromptOptions
            {
                Prompt = ActivityFactory.FromObject(_templates.Evaluate("AskForMailNickname")),
            };

            // Retrieve userinput from the previous step in this WaterfallDialog and put the value in a global object.
            var displayNameInput = (ManageUserClass)stepContext.Values[manageUserInputStr];
            displayNameInput.displayName = (string)stepContext.Result;

            manageUserClass.displayName = displayNameInput.displayName;

            // Redefine object of ManageUserClass to retrieve userinput in the next WaterfallStep.
            stepContext.Values[manageUserInputStr] = new ManageUserClass();

            return await stepContext.PromptAsync(nameof(TextPrompt), promptOptions, cancellationToken);
        }

        private async Task<DialogTurnResult> UserPrincipalNameStepAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            // Define the messageprompt for this WaterfallStep.
            var promptOptions = new PromptOptions
            {
                Prompt = ActivityFactory.FromObject(_templates.Evaluate("AskForUserPrincipalName")),
            };

            // Retrieve userinput from the previous step in this WaterfallDialog and put the value in a global object.
            var mailNicknameInput = (ManageUserClass)stepContext.Values[manageUserInputStr];
            mailNicknameInput.mailNickname = (string)stepContext.Result;

            manageUserClass.mailNickname = mailNicknameInput.mailNickname;

            // Redefine object of ManageUserClass to retrieve userinput in the next WaterfallStep.
            stepContext.Values[manageUserInputStr] = new ManageUserClass();

            return await stepContext.PromptAsync(nameof(TextPrompt), promptOptions, cancellationToken);
        }
        
        private async Task<DialogTurnResult> AccountEnabledStepAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            // Define the messageprompt for this WaterfallStep.
            var promptOptions = new PromptOptions
            {
                Prompt = ActivityFactory.FromObject(_templates.Evaluate("AccountEnabledPrompt")),
            };

            // Retrieve userinput from the previous step in this WaterfallDialog and put the value in a global object.
            var userPrincipalNameInput = (ManageUserClass)stepContext.Values[manageUserInputStr];
            userPrincipalNameInput.userPrincipalName = (string)stepContext.Result;

            manageUserClass.userPrincipalName = userPrincipalNameInput.userPrincipalName;

            // Redefine object of ManageUserClass to retrieve userinput in the next WaterfallStep.
            stepContext.Values[manageUserInputStr] = new ManageUserClass();

            return await stepContext.PromptAsync(nameof(ConfirmPrompt), promptOptions, cancellationToken);
        }

        private async Task<DialogTurnResult> PostNewUserStepAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            // Define the messageprompt for this WaterfallStep.
            var promptOptions = new PromptOptions
            {
                Prompt = ActivityFactory.FromObject(_templates.Evaluate("UsercreatedSuccessMessage")),
            };

            // Retrieve userinput from the previous step in this WaterfallDialog and put the value in a global object.
            var accountEnabledInput = (ManageUserClass)stepContext.Values[manageUserInputStr];
            accountEnabledInput.accountEnabled = (bool)stepContext.Result;

            manageUserClass.accountEnabled = accountEnabledInput.accountEnabled;

            // Use your authenticationtoken and the fully filled global object to create a new user 
            // with the SimpleGraphClient
            var tokenResponse = logintoken;
            var client = new SimpleGraphClient(tokenResponse.Token);
            await client.PostCreateUserAsync(manageUserClass);

            // Reset the global object for later use and redirect to the helpdialog.
            manageUserClass.resetValues();

            await stepContext.PromptAsync(nameof(TextPrompt), promptOptions, cancellationToken);
            return await stepContext.ReplaceDialogAsync("helpWaterfall");
        }

        //private async Task<DialogTurnResult> AssignLicenseStepAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        //{
        //    var promptOptions = new PromptOptions
        //    {
        //        Prompt = ActivityFactory.FromObject(_templates.Evaluate("LicenseAssignedSuccessMessage")),
        //        //Prompt = MessageFactory.Text("License assigned."),
        //    };

        //    await stepContext.PromptAsync(nameof(TextPrompt), promptOptions, cancellationToken);
        //    return await stepContext.ReplaceDialogAsync("helpWaterfall");
        //}

        private async Task<DialogTurnResult> GroupDisplayNameStepAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            if (manageGroupMode == "create")
            {
                // Define the messageprompt for this WaterfallStep.
                var promptOptions = new PromptOptions
                {
                    Prompt = ActivityFactory.FromObject(_templates.Evaluate("GroupDisplaynamePrompt")),
                };

                // Define object of ManageGroupClass to retrieve userinput in the next WaterfallStep.
                stepContext.Values[manageGroupInputStr] = new ManageGroupClass();

                return await stepContext.PromptAsync(nameof(TextPrompt), promptOptions, cancellationToken);
            }
            else if (manageGroupMode == "update")
            {
                // Define the messageprompt for this WaterfallStep.
                var promptOptions = new PromptOptions
                {
                    Prompt = ActivityFactory.FromObject(_templates.Evaluate("UpdateGroupDisplaynamePrompt")),
                };

                // Retrieve userinput from the previous step in this WaterfallDialog and put the value in a global object.
                var groupIdInput = (ManageGroupClass)stepContext.Values[manageGroupInputStr];
                groupIdInput.groupId = (string)stepContext.Result;

                manageGroupClass.groupId = groupIdInput.groupId;

                // Use your authenticationtoken and groupId to retrieve the data from the existing group
                // with the SimpleGraphClient
                var tokenResponse = logintoken;
                var client = new SimpleGraphClient(tokenResponse.Token);
                Group currentgroup = await client.GetExistingGroupAsync(groupIdInput.groupId);

                // Fill global object with current data of the existing group
                manageGroupClass.groupDisplayName = currentgroup.DisplayName;
                manageGroupClass.groupDescription = currentgroup.Description;
                manageGroupClass.groupMailNickname = currentgroup.MailNickname;

                // Define object of ManageGroupClass to retrieve userinput in the next WaterfallStep.
                stepContext.Values[manageGroupInputStr] = new ManageGroupClass();

                return await stepContext.PromptAsync(nameof(TextPrompt), promptOptions, cancellationToken);
            }
            await stepContext.Context.SendActivityAsync(ActivityFactory.FromObject(_templates.Evaluate("SomethingWentWrongMessage")));
            return await stepContext.ReplaceDialogAsync("helpWaterfall");
        }

        private async Task<DialogTurnResult> GroupDescriptionStepAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            if (manageGroupMode == "create")
            {
                // Define the messageprompt for this WaterfallStep.
                var promptOptions = new PromptOptions
                {
                    Prompt = ActivityFactory.FromObject(_templates.Evaluate("GroupDescriptionPrompt")),
                };

                // Retrieve userinput from the previous step in this WaterfallDialog and put the value in a global object.
                var groupDisplayNameInput = (ManageGroupClass)stepContext.Values[manageGroupInputStr];
                groupDisplayNameInput.groupDisplayName = (string)stepContext.Result;

                manageGroupClass.groupDisplayName = groupDisplayNameInput.groupDisplayName;

                // Redefine object of ManageGroupClass to retrieve userinput in the next WaterfallStep.
                stepContext.Values[manageGroupInputStr] = new ManageGroupClass();

                return await stepContext.PromptAsync(nameof(TextPrompt), promptOptions, cancellationToken);
            }
            else if (manageGroupMode == "update")
            {
                // Define the messageprompt for this WaterfallStep.
                var promptOptions = new PromptOptions
                {
                    Prompt = ActivityFactory.FromObject(_templates.Evaluate("UpdateGroupDescriptionPrompt")),
                };

                // Retrieve userinput from the previous step in this WaterfallDialog.
                var groupDisplayNameInput = (ManageGroupClass)stepContext.Values[manageGroupInputStr];
                groupDisplayNameInput.groupDisplayName = (string)stepContext.Result;

                if (groupDisplayNameInput.groupDisplayName == "/")
                {
                    // Redefine object of ManageGroupClass to retrieve userinput in the next WaterfallStep.
                    stepContext.Values[manageGroupInputStr] = new ManageGroupClass();
                    return await stepContext.PromptAsync(nameof(TextPrompt), promptOptions, cancellationToken);
                }
                else
                {
                    manageGroupClass.groupDisplayName = groupDisplayNameInput.groupDisplayName;

                    // Redefine object of ManageGroupClass to retrieve userinput in the next WaterfallStep.
                    stepContext.Values[manageGroupInputStr] = new ManageGroupClass();
                    return await stepContext.PromptAsync(nameof(TextPrompt), promptOptions, cancellationToken);
                }                
            }
            await stepContext.Context.SendActivityAsync(ActivityFactory.FromObject(_templates.Evaluate("SomethingWentWrongMessage")));
            return await stepContext.ReplaceDialogAsync("helpWaterfall");

        }

        private async Task<DialogTurnResult> GroupMailNicknameStepAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            if (manageGroupMode == "create")
            {
                // Define the messageprompt for this WaterfallStep.
                var promptOptions = new PromptOptions
                {
                    Prompt = ActivityFactory.FromObject(_templates.Evaluate("GroupMailNicknamePrompt")),
                };

                // Retrieve userinput from the previous step in this WaterfallDialog and put the value in a global object.
                var groupDescriptionInput = (ManageGroupClass)stepContext.Values[manageGroupInputStr];
                groupDescriptionInput.groupDescription = (string)stepContext.Result;

                manageGroupClass.groupDescription = groupDescriptionInput.groupDescription;

                // Redefine object of ManageGroupClass to retrieve userinput in the next WaterfallStep.
                stepContext.Values[manageGroupInputStr] = new ManageGroupClass();

                return await stepContext.PromptAsync(nameof(TextPrompt), promptOptions, cancellationToken);
            }
            else if (manageGroupMode == "update")
            {
                // Define the messageprompt for this WaterfallStep.
                var promptOptions = new PromptOptions
                {
                    Prompt = ActivityFactory.FromObject(_templates.Evaluate("UpdateGroupMailNicknamePrompt")),
                };

                // Retrieve userinput from the previous step in this WaterfallDialog.
                var groupDescriptionInput = (ManageGroupClass)stepContext.Values[manageGroupInputStr];
                groupDescriptionInput.groupDescription = (string)stepContext.Result;

                if (groupDescriptionInput.groupDescription == "/")
                {
                    // Redefine object of ManageGroupClass to retrieve userinput in the next WaterfallStep.
                    stepContext.Values[manageGroupInputStr] = new ManageGroupClass();
                    return await stepContext.PromptAsync(nameof(TextPrompt), promptOptions, cancellationToken);
                }
                else
                {
                    manageGroupClass.groupDescription = groupDescriptionInput.groupDescription;

                    // Redefine object of ManageGroupClass to retrieve userinput in the next WaterfallStep.
                    stepContext.Values[manageGroupInputStr] = new ManageGroupClass();
                    return await stepContext.PromptAsync(nameof(TextPrompt), promptOptions, cancellationToken);
                }
            }
            await stepContext.Context.SendActivityAsync(ActivityFactory.FromObject(_templates.Evaluate("SomethingWentWrongMessage")));
            return await stepContext.ReplaceDialogAsync("helpWaterfall");
        }

        private async Task<DialogTurnResult> PostNewGroupStepAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            if (manageGroupMode == "create") {
                // Define the messageprompt for this WaterfallStep.
                var promptOptions = new PromptOptions
                {
                    Prompt = ActivityFactory.FromObject(_templates.Evaluate("GroupCreatedMessage")),
                };

                // Retrieve userinput from the previous step in this WaterfallDialog and put the value in a global object.
                var groupMailNicknameInput = (ManageGroupClass)stepContext.Values[manageGroupInputStr];
                groupMailNicknameInput.groupMailNickname = (string)stepContext.Result;

                manageGroupClass.groupMailNickname = groupMailNicknameInput.groupMailNickname;

                // Use your authenticationtoken and the fully filled global object to create a new group
                // with the SimpleGraphClient
                var tokenResponse = logintoken;
                var client = new SimpleGraphClient(tokenResponse.Token);
                await client.PostUpdateCreateGroupAsync(manageGroupClass, manageGroupMode);

                // Reset the global object for later use and redirect to the helpdialog.
                manageGroupClass.resetValues();

                await stepContext.PromptAsync(nameof(TextPrompt), promptOptions, cancellationToken);
                return await stepContext.ReplaceDialogAsync("helpWaterfall");
            }
            else if (manageGroupMode == "update")
            {
                // Define the messageprompt for this WaterfallStep.
                var promptOptions = new PromptOptions
                {
                    Prompt = ActivityFactory.FromObject(_templates.Evaluate("GroupUpdatedMessage")),
                };

                // Retrieve userinput from the previous step in this WaterfallDialog.
                var groupMailNicknameInput = (ManageGroupClass)stepContext.Values[manageGroupInputStr];
                groupMailNicknameInput.groupMailNickname = (string)stepContext.Result;

                if (groupMailNicknameInput.groupMailNickname == "/")
                {
                    // Use your authenticationtoken and the fully filled global object to update an existing group
                    // with the SimpleGraphClient
                    var tokenResponse = logintoken;
                    var client = new SimpleGraphClient(tokenResponse.Token);
                    await client.PostUpdateCreateGroupAsync(manageGroupClass, manageGroupMode);

                    // Reset the global object and manageGroupMode for later use and redirect to the helpdialog.
                    manageGroupClass.resetValues();
                    manageGroupMode = "create";

                    await stepContext.PromptAsync(nameof(TextPrompt), promptOptions, cancellationToken);
                    return await stepContext.ReplaceDialogAsync("helpWaterfall");

                }
                else
                {
                    manageGroupClass.groupMailNickname = groupMailNicknameInput.groupMailNickname;

                    // Use your authenticationtoken and the fully filled global object to update an existing group
                    // with the SimpleGraphClient
                    var tokenResponse = logintoken;
                    var client = new SimpleGraphClient(tokenResponse.Token);
                    await client.PostUpdateCreateGroupAsync(manageGroupClass, manageGroupMode);

                    // Reset the global object and manageGroupMode for later use and redirect to the helpdialog.
                    manageGroupClass.resetValues();
                    manageGroupMode = "create";

                    await stepContext.PromptAsync(nameof(TextPrompt), promptOptions, cancellationToken);
                    return await stepContext.ReplaceDialogAsync("helpWaterfall");
                }


            }
            await stepContext.Context.SendActivityAsync(ActivityFactory.FromObject(_templates.Evaluate("SomethingWentWrongMessage")));
            return await stepContext.ReplaceDialogAsync("helpWaterfall");
        }

        private async Task<DialogTurnResult> GroupIdStepAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            // Define the messageprompt for this WaterfallStep.
            var promptOptions = new PromptOptions
            {
                Prompt = ActivityFactory.FromObject(_templates.Evaluate("GroupIdPrompt")),
            };

            manageGroupMode = "update";

            // Define object of ManageGroupClass to retrieve userinput in the next WaterfallStep.
            stepContext.Values[manageGroupInputStr] = new ManageGroupClass();

            return await stepContext.PromptAsync(nameof(TextPrompt), promptOptions, cancellationToken);
        }

        private async Task<DialogTurnResult> GroupIdDeleteStepAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            // Define the messageprompt for this WaterfallStep.
            var promptOptions = new PromptOptions
            {
                Prompt = ActivityFactory.FromObject(_templates.Evaluate("DeleteGroupIdPrompt")),
            };

            // Redefine object of ManageGroupClass to retrieve userinput in the next WaterfallStep.
            stepContext.Values[manageGroupInputStr] = new ManageGroupClass();

            return await stepContext.PromptAsync(nameof(TextPrompt), promptOptions, cancellationToken);
        }

        private async Task<DialogTurnResult> GroupDeleteConfirmationStepAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            // Define the messageprompt for this WaterfallStep.
            var promptOptions = new PromptOptions
            {
                Prompt = ActivityFactory.FromObject(_templates.Evaluate("GroupConfirmDeletePrompt")),
            };

            // Retrieve userinput from the previous step in this WaterfallDialog and put the value in a global object.
            var groupIdInput = (ManageGroupClass)stepContext.Values[manageGroupInputStr];
            groupIdInput.groupId = (string)stepContext.Result;

            manageGroupClass.groupId = groupIdInput.groupId;

            // Redefine object of ManageGroupClass to retrieve userinput in the next WaterfallStep.
            stepContext.Values[manageGroupInputStr] = new ManageGroupClass();
            return await stepContext.PromptAsync(nameof(ConfirmPrompt), promptOptions, cancellationToken);
        }
        private async Task<DialogTurnResult> GroupDeleteStepAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            // Retrieve userinput from the previous step in this WaterfallDialog and put the value in a global object.
            var confirmDeleteInput = (ManageGroupClass)stepContext.Values[manageGroupInputStr];
            confirmDeleteInput.confirmDeleteGroup = (bool)stepContext.Result;

            manageGroupClass.confirmDeleteGroup = confirmDeleteInput.confirmDeleteGroup;

            if (confirmDeleteInput.confirmDeleteGroup)
            {
                // Use your authenticationtoken and the groupId to delete an existing group
                // with the SimpleGraphClient
                var tokenResponse = logintoken;
                var client = new SimpleGraphClient(tokenResponse.Token);
                await client.DeleteGroupAsync(manageGroupClass.groupId);

                // Reset the global object for later use and redirect to the helpdialog.
                manageGroupClass.resetValues();

                await stepContext.Context.SendActivityAsync(ActivityFactory.FromObject(_templates.Evaluate("GroupDeleteSuccessMessage")));
            } else
            {
                await stepContext.Context.SendActivityAsync(ActivityFactory.FromObject(_templates.Evaluate("GroupCancelDeleteMessage")));
            }

            return await stepContext.ReplaceDialogAsync("helpWaterfall");

        }

        //private async Task<DialogTurnResult> Step01Async(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        //{
        //    return await stepContext.ReplaceDialogAsync("helpWaterfall");
        //}
        //private async Task<DialogTurnResult> Step02Async(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        //{
        //    return await stepContext.ReplaceDialogAsync("helpWaterfall");
        //}
        //private async Task<DialogTurnResult> Step03Async(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        //{
        //    return await stepContext.ReplaceDialogAsync("helpWaterfall");
        //}
        //private async Task<DialogTurnResult> Step04Async(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        //{
        //    return await stepContext.ReplaceDialogAsync("helpWaterfall");
        //}
        //private async Task<DialogTurnResult> Step05Async(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        //{
        //    return await stepContext.ReplaceDialogAsync("helpWaterfall");
        //}

        //private async Task<DialogTurnResult> GetExistingGroupStepAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        //{
        //    var promptOptions = new PromptOptions
        //    {
        //        Prompt = ActivityFactory.FromObject(_templates.Evaluate("GroupIdPrompt")),
        //    };

        //    var groupIdInput = (ManageGroupClass)stepContext.Values[manageGroupInputStr];
        //    groupIdInput.groupMailNickname = (string)stepContext.Result;

        //    manageGroupClass.groupId = groupIdInput.groupId;

        //    var tokenResponse = logintoken;
        //    var client = new SimpleGraphClient(tokenResponse.Token);
        //    Group currentgroup = await client.GetExistingGroupAsync(groupIdInput.groupId);

        //    manageGroupClass.groupDisplayName = currentgroup.DisplayName;
        //    manageGroupClass.groupDescription = currentgroup.Description;
        //    manageGroupClass.groupMailNickname = currentgroup.MailNickname;


        //    stepContext.Values[manageGroupInputStr] = new ManageGroupClass();

        //    return await stepContext.Context.SendActivityAsync(ActivityFactory.FromObject(_templates.Evaluate("PasswordResetFailMessage")));
        //}

        //private async Task ShowMeAsync()
        //{
        //    WaterfallStepContext stepContext = new WaterfallStepContext();
        //    var tokenResponse = (TokenResponse)stepContext.Result;
        //    var client = new SimpleGraphClient(tokenResponse.Token);
        //    var me = await client.GetMeAsync();
        //    var title = !string.IsNullOrEmpty(me.JobTitle) ?
        //                me.JobTitle : "Unknown";

        //    await stepContext.Context.SendActivityAsync(
        //        $"You're logged in as {me.DisplayName} ({me.UserPrincipalName})." +
        //        $"\n\nYour job title is: {title}");

        //    IsLoggedIn = true;
        //}
    }
}
